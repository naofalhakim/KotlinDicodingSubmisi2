package com.example.user.finalsubmisi2.model

data class myLigaModel(
    val events : List<TeamMatch>)