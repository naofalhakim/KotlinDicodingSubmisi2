package com.example.user.finalsubmisi2.model

data class myBadge(
    val teams : List<TeamDetail>)