package com.example.user.finalsubmisi2.model

import com.google.gson.annotations.SerializedName

data class TeamDetail(
    @SerializedName("strTeamBadge")
    var strTeamBadge: String? = null

)